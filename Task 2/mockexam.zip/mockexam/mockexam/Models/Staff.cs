﻿namespace mockexam.Models
{
    public class Staff
    {
        public int StaffId { get; set; }
        public string JobTitle { get; set; }
        public string Bio { get; set; }
        public string StaffFullName { get; set; }

    }
}
