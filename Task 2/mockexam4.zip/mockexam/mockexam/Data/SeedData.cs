﻿using Microsoft.AspNetCore.Identity;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.EntityFrameworkCore;
using mockexam.Models;
using System.Threading.Tasks;

namespace mockexam.Data
{
    public class SeedData
    {
        public static async Task mockexamAsync(ApplicationDbContext context, UserManager<IdentityUser> userManager)
        {
            if (await context.Rooms.AnyAsync() == false) // checks for any rooms in table
            {
                var SeededRooms = new List<Rooms> // creates a new list for rooms to be seeded
                {
                    new Rooms // individual rooms
                    {
                        RoomName = "Room 1",
                        Description = "This room is a newly furnished office space.",
                        Capacity = 10,
                        HourlyRate = 120.99,
                        City = "Wolverhampton",
                        isAvailable = true,

                    },
                    new Rooms
                    {
                        RoomName = "Room 2",
                        Description = "This room is a newly furnished apartment",
                        Capacity = 4,
                        HourlyRate = 30.49,
                        City = "Wednesbury",
                        isAvailable = true,

                    },
                    new Rooms
                    {
                        RoomName = "Room 3",
                        Description = "This room is abandoned.",
                        Capacity = 1,
                        HourlyRate = 1.99,
                        City = "Wednesbury",
                        isAvailable = false,

                    }

                };
                await context.Rooms.AddRangeAsync(SeededRooms);
                await context.SaveChangesAsync(); // saves changes
            }

            if (await context.Staff.AnyAsync() == false)
            {
                var SeededStaff = new List<Staff>
                {
                    new Staff
                    {
                        JobTitle = "Manager",
                        Bio = " I am the Manager of finance for CityPoint Room Hire.",
                        StaffFullName = "Johnathan Brownington",
                    },
                    new Staff
                    {
                        JobTitle = "Staff",
                        Bio = "I am a receptionist at CityPoint Room Hire.",
                        StaffFullName = "Lindsey Lobrian"

                    },
                    new Staff
                    {
                        JobTitle = "Staff",
                        Bio = "I am a Customer Support Agent at CityPoint Room Hire",
                        StaffFullName = "Jeremy Clarkson"
                    }

                };
                await context.Staff.AddRangeAsync(SeededStaff);
                await context.SaveChangesAsync(); // saves changes
            }
            if (await context.Bookings.AnyAsync() == false)
            {
                var user1 = await userManager.FindByEmailAsync("user1@example.com");
                var admin = await userManager.FindByEmailAsync("admin@example.com");
                if (user1 != null && admin != null)
                {
                    var seededBookings = new List<Bookings>
                    {
                        new Bookings
                        {
                            UserId = user1.Id,
                            CheckInDate = DateTime.Now.AddDays(1),
                            CheckOutDate = DateTime.Now.AddDays(2),
                            Status = "Confirmed",
                            BookingCreatedAt = DateTime.Now
                        },
                        new Bookings
                        {
                            UserId = admin.Id,
                            CheckInDate = DateTime.Now.AddDays(5),
                            CheckOutDate = DateTime.Now.AddDays(7),
                            Status = "Pending",
                            BookingCreatedAt = DateTime.Now
                        },
                    };
                    await context.Bookings.AddRangeAsync(seededBookings);
                    await context.SaveChangesAsync();
                }

            }
        }

        
        public static async Task SeedRoles(IServiceProvider serviceProvider, UserManager<IdentityUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            string[] roleNames = { "Admin", "Manager", "Staff", "User" }; // list of role names
            foreach (var roleName in roleNames)
            {
                var roleExist = await roleManager.RoleExistsAsync(roleName);
                if (!roleExist)
                {
                    var role = new IdentityRole(roleName);
                    await roleManager.CreateAsync(role);
                }
            }
            var adminUser = await userManager.FindByEmailAsync("admin@example.com"); // admin credentials
            if (adminUser == null)
            {
                adminUser = new IdentityUser { UserName = "admin@example.com", Email = "admin@example.com", EmailConfirmed = true };
                await userManager.CreateAsync(adminUser, "Admin123!");
            }
            if (!await userManager.IsInRoleAsync(adminUser, "Admin"))
            {
                await userManager.AddToRoleAsync(adminUser, "Admin");
            }

            var managerpositionUser = await userManager.FindByEmailAsync("manager@example.com"); // manager credentials
            if (managerpositionUser == null)
            {
                managerpositionUser = new IdentityUser { UserName = "manager@example.com", Email = "manager@example.com", EmailConfirmed = true };
                await userManager.CreateAsync(managerpositionUser, "Manager123!");
            }
            if (!await userManager.IsInRoleAsync(managerpositionUser, "Manager"))
            {
                await userManager.AddToRoleAsync(managerpositionUser, "Manager");
            }

            var staffUser = await userManager.FindByEmailAsync("staff@example.com"); // staff credentials
            if (staffUser == null)
            {
                staffUser = new IdentityUser { UserName = "staff@example.com", Email = "staff@example.com", EmailConfirmed = true };
                await userManager.CreateAsync(staffUser, "Staff123!");
            }
            if (!await userManager.IsInRoleAsync(staffUser, "Staff"))
            {
                await userManager.AddToRoleAsync(staffUser, "Staff");
            }

            var standardUser1 = await userManager.FindByEmailAsync("user1@example.com");
            if (standardUser1 == null)
            {
                standardUser1 = new IdentityUser { UserName = "user1@example.com", Email = "user1@example.com", EmailConfirmed = true };
                await userManager.CreateAsync(standardUser1, "User1123!");
            }
            if (!await userManager.IsInRoleAsync(standardUser1, "User"))
            {
                await userManager.AddToRoleAsync(standardUser1, "User");
            }
        }
        
    }
}
