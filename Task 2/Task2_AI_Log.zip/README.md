This is the ReadME of my January Mock Exam.
To run the program, please ensure that these 3 packages are installed at the latest version of NET 9.0.
-- Microsoft.AspNetCore.Authentication.Google @ 9.0.12
-- Microsoft.EntityFrameworkCore.SqlServer @ 9.0.12
-- Microsoft.VisualStudio.Web.CodeGeneration.Design @ 9.0.12
-- Microsoft.EntityFrameworkCore @ 9.0.12

To run the application, please press the dropdown selector where it says HTTP/HTTPS and select HTTP.
<img width="285" height="299" alt="{4C1A93D8-1380-4CEE-AA2D-DF61C7CC7517}" src="https://github.com/user-attachments/assets/fafd3814-1ce8-4d02-b979-9a5c618f134b" />

Then, press the green 'Play' button to start the website. -->
<img width="63" height="35" alt="{7B9CEC94-1B09-4981-AEDF-EBBF149C6E77}" src="https://github.com/user-attachments/assets/ce7d348e-0a39-432e-8082-f6cbd6c12f14" />

You are now running the application, if any errors have occured please use online resources to help you.
User Credentials are as follows:
Email: user1@example.com
Password: User1123!
This is your standalone regular user with no elevated permissions.

Email: staff@example.com
Password: Staff123!
This is the account for staff to access.

Email: manager@example.com
Password:Manager123!
This is the account for the Manager to access.

Email: admin@example.com
Password: Admin123!
This is the highest elevation permission for the user accounts.

 Please use these demo accounts when using the website.
